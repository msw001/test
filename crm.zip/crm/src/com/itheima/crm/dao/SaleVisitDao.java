package com.itheima.crm.dao;

import com.itheima.crm.domain.SaleVisit;

/**
 * 客户拜访记录的DAO的接口
 * @author jt
 *
 */
public interface SaleVisitDao extends BaseDao<SaleVisit>{

}
