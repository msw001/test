package com.itheima.crm.dao.impl;

import java.util.List;

import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import com.itheima.crm.dao.UserDao;
import com.itheima.crm.domain.Customer;
import com.itheima.crm.domain.User;

public class UserDaoImpl extends BaseDaoImpl<User> implements UserDao {

	

	@Override
	// DAO中根据用户名和密码进行查询的方法:
	public User login(User user) {
		List<User> list = (List<User>) this.getHibernateTemplate().find(
				"from User where user_code=? and user_password = ?", user.getUser_code(), user.getUser_password());
		
		// 判断一下:如果为空，get(0)会报错，先判断下
		if (list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

}
