package com.itheima.crm.service;

import java.util.List;

import com.itheima.crm.domain.User;

public interface UserService {

	void register(User user);

	User login(User user);

	List<User> findAll();

}
